#if TOOLS
using Godot;
using System;

[Tool]
public partial class BrsSSS_Main : EditorPlugin
{
    BrsSSS_Panel panel;
    private PackedScene toolPanel = GD.Load<PackedScene>("res://addons/BrsSSS/Scenes/BrsSSS_Panel.tscn");
    //TscnDataHandler tscnDataHandler;

    public BrsSSS_Main()
    {
        
    }

    public override void _EnterTree()
    {
        panel = toolPanel.Instantiate<BrsSSS_Panel>();
        panel.editorPlugin = (EditorPlugin)this;

		AddControlToDock(EditorPlugin.DockSlot.LeftUl, panel);
        //tilwahetowihgwoh
    }

    public override void _ExitTree()
    {
        RemoveControlFromDocks(panel);
        panel.QueueFree(); // Free the instance
    }
}
#endif
