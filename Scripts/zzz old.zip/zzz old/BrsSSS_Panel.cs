#if TOOLS
using Godot;
using System;
using System.Collections.Generic;
using BrsLib;
using System.Linq;
using System.Text.RegularExpressions;
using System.IO;

[Tool]
public partial class BrsSSS_Panel : Panel, ISerializationListener
{

    #region ----- UI node Declaration  -----
        
        // Declare UI nodes
        Button nodeToMethod_Button;
        Button nodeToVar_Button;

        Button selectedToCustom1_Button;
        TextEdit customTemplate1_TextEdit;

        Button selectedToCustom2_Button;
        TextEdit customTemplate2_TextEdit;

        Button selectedToCustom3_Button;
        TextEdit customTemplate3_TextEdit;

        Button node1_Button;
        Button node2_Button;

        Button delGDtemp_Button;

        Button disableAddons_Button;
        Button enableAddons_Button;
        Button restartAddons_Button;

        Button createNodeTemplate_Button;

        Button openUserFolder_Button;
        Button openProjectFolder_Button;

        TextEdit addonNames_TextEdit;

        BrsConfigManager brsConfigManager;

        Button toggleScriptLanguage_CheckButton;

        Button gotIt_Button;

        Button manual_Button;

        Button test_Button;

        CheckBox setUnique_CheckBox;



    #endregion ----- UI node Declaration  -----

    #region ----- Variables -----

        [Export]
        public string[] addonNames; 

        // Variables:
        int buttonPresses = 0;

        private readonly Dictionary<string, Godot.Variant> DefaultBackupOptions;
        string configFilePath = "res://addons/BrsSSS/BrsSSS_config.json"; // Rename Template into addon name

        Node selectedNode1;
        Node selectedNode2;

        bool useGDscript = false;

        public EditorPlugin editorPlugin;

        bool setUnique = false;

        //EditorInterface editorInterface;

    #endregion ----- Variables -----

    // Constructor
    public BrsSSS_Panel()
    {   
        // Load the theme resource (adjust the path to your actual theme file).
        Theme myTheme = GD.Load<Theme>("res://addons/BrsLib/GDThemes/DarkNYellow.tres");
        
        // Set this node's theme.
        Theme = myTheme;

        // Initialize the dictionary in the constructor
        DefaultBackupOptions = new Dictionary<string, Godot.Variant>
        {
            // Button Presses
            { "addonNames_TextEdit", new string[1] },
            { "toggleScriptLanguage_CheckButton", false },
            { "gotIt_Button", false },
            { "customText1", new string[1] },
            { "customText2", new string[1] },
            { "customText3", new string[1] },
            { "setUnique", false }
        };
    }

    public override void _EnterTree()
    {   
        //GD.Print($"(TemplatePanel, _EnterTree) started!");
       
        #region - Initialize Variables -
           
            brsConfigManager = new();
            brsConfigManager.DefaultConfigFilePath = configFilePath;
            brsConfigManager.InitializeDefaultConfig(DefaultBackupOptions); // Populate defaults
            brsConfigManager.parentNode = (Node)this;

            // Load Config from file:
            brsConfigManager.LoadConfig();
            
        #endregion - Initialize Variables -

        InitializeUINodes();
    }

    #region ----- UI Methods -----


        public void OnTest_Button()
        {
            //MakeSelectedNodeUnique();
        }

        public void OnSetUnique_CheckBox(bool isToggled)
        {
            setUnique = isToggled;
            brsConfigManager.Set("setUnique", isToggled);
            SaveConfig();
        }

        //Works
        public void MakeSelectedNodeUniqueOld()
        {
            Node selectedNode = BrsEditor.GetSelectedNode(); // Get first selected node

            if (selectedNode == null)
            {
                GD.PrintErr("No node selected!");
                return;
            }
         
            // Now mark the node as unique
            selectedNode.SetUniqueNameInOwner(true);
        }


        public void OnCustomTemplate1_TextEdit()
        {
            brsConfigManager.Set("customText1", customTemplate1_TextEdit.Text);
            SaveConfig();
        }

        public void OnCustomTemplate2_TextEdit()
        {
            brsConfigManager.Set("customText2", customTemplate2_TextEdit.Text);
            SaveConfig();
        }


        public void OnCustomTemplate3_TextEdit()
        {
            brsConfigManager.Set("customText3", customTemplate3_TextEdit.Text);
            SaveConfig();
        }


        public void OnSelectedToCustom1_Button()
        {
            SelectedNodeToTemplate(customTemplate1_TextEdit);
        }

        public void OnSelectedToCustom2_Button()
        {
            SelectedNodeToTemplate(customTemplate2_TextEdit);
        }

        public void OnSelectedToCustom3_Button()
        {
            SelectedNodeToTemplate(customTemplate3_TextEdit);
        }


        private void SelectedNodeToTemplate(TextEdit textEdit)
        {
            string customCode = textEdit.Text;

            Node selectedNode = BrsEditor.GetSelectedNode();
            if (selectedNode == null)
            {
                return;
            }

            string template = ReplaceTags(customCode, selectedNode);
            DisplayServer.ClipboardSet(template);
        }

        private string ReplaceTags(string template, Node selectedNode)
        {
            // Create a dictionary to store placeholders and their corresponding values
            var placeholders = new Dictionary<string, string>
            {
                { "NodeType", selectedNode.GetType().Name },
                { "NodeName", selectedNode.Name },
                { "NodePath", BrsEditor.GetSelectedNodePath() }
            };

            // Replace <<...>> placeholders
            var replacePlaceholdersRegex = new Regex(@"<<([^<>]+)>>");
            string result = replacePlaceholdersRegex.Replace(template, match =>
            {
                string key = match.Groups[1].Value; // Extract the text inside <<...>>
                if (placeholders.ContainsKey(key))
                {
                    return placeholders[key]; // Replace with the corresponding value
                }
                return match.Value; // Leave as-is if no match in the dictionary
            });

            if(setUnique)
            {
                // Detect and process unique node references
                BrsEditor.DetectAndMakeNodesUnique(result, editorPlugin);
            }
            return result;
        }


        public void OnManual_Button()
        {
            string absolutePath = ProjectSettings.GlobalizePath("res://addons/BrsSSS/Manual/manual.html");

            OS.ShellOpen(absolutePath);
        }

        public void OnGotIt_Button()
        {
            Control nodeToHide = (Control)GetNode("%GotIt_VBoxContainer");
            nodeToHide.Visible = false;
            brsConfigManager.Set("gotIt_Button", true);
            SaveConfig();
        }

        public void OnToggleScriptLanguage_CheckButton(bool toggled)
        {
            useGDscript = toggled;
            //GD.Print($"useGDscript: {useGDscript}");

            brsConfigManager.Set("toggleScriptLanguage_CheckButton", toggled);
            SaveConfig();
        }

        private void SetNode1()
        {
            selectedNode1 = BrsEditor.GetSelectedNode();
            //GD.Print($"Node1: {selectedNode1.Name}");
        }

        private void SetNode2()
        {
            selectedNode2 = BrsEditor.GetSelectedNode();
            //GD.Print($"Node2: {selectedNode2.Name}");

            string returnVal = BrsNode.GetNodeAPathToB(selectedNode1, selectedNode2);
            DisplayServer.ClipboardSet(returnVal);
        }


        private void OnCreateNodeTemplate_Button()
        {
            Node selectedNode = BrsEditor.GetSelectedNode();
            if (selectedNode == null)
            {
                return;
            }

            string nodeName = selectedNode.Name;
            string nodeType = selectedNode.GetClass(); // This returns the Godot class name, e.g. "Button", "Control"
            string nodePath = BrsEditor.GetSelectedNodePath();

            // If no node was selected, exit early
            if (string.IsNullOrEmpty(nodePath))
            {
                return; 
            }

            string template;

            // Build the template string using concatenation so the literal itself is not indented in the .cs file.
            // You can adjust the "\t" strings if you prefer spaces.
            if(!useGDscript)
            {
                template = 
                    $"{nodeType} {nodeName};\n" +
                    $"{nodeName} = ({nodeType})GetNode(\"{nodePath}\");\n" +
                    $"{nodeName}.Pressed += On{nodeName};\n\n" +
                    $"public void On{nodeName}()\n" +
                    "{\n" +
                    "\t// Your code here\n" +
                    "}\n";
            }
            else
            {
                template = 
                    $"var {nodeName} = get_node(\"{nodePath}\")\n" +
                    $"{nodeName}.pressed.connect(_on_{nodeName}_pressed)\n\n" +
                    $"func _on_{nodeName}_pressed():\n" +
                    "\t# Your code here\n";
            }
            DisplayServer.ClipboardSet(template);
            //GD.Print($"Generated template copied to clipboard:\n{template}");
        }

        private void OnCopyNodePath_Get()
        {
            //GD.Print($"(TscnData, OnCopyNodePathWithMethod1) started ------");

            // Get the actual path of the node within the scene
            string nodePath = BrsEditor.GetSelectedNodePath();  // This will return the runtime path (relative to the scene root)

            // If no node was selected, exit early
            if (string.IsNullOrEmpty(nodePath))
            {
                return; 
            }

            //GD.Print($"(BrsSSS_Panel, OnCopyNodePathWithMethod1) nodePath: {nodePath}\n");
            string returnVal;

            if(!useGDscript)
            {
                // Prepare the result string to copy to the clipboard
                returnVal = $"GetNode(\"{nodePath}\");";
            }
            else
            {
                returnVal = $"get_node(\"{nodePath}\");";
            }

            // Copy the result into the clipboard
            DisplayServer.ClipboardSet(returnVal);
            //GD.Print($"(BrsSSS_Panel, OnCopyNodePathWithMethod1) Copied to clipboard: {returnVal}\n");
        }

        private void OnCopyNodePath_Var()
        {
            //GD.Print($"(TscnData, OnCopyNodePathWithMethod1) started ------");

            // Get the actual path of the node within the scene
            string nodePath = BrsEditor.GetSelectedNodePath();  // This will return the runtime path (relative to the scene root)
            
            // If no node was selected, exit early
            if (string.IsNullOrEmpty(nodePath))
            {
                return; 
            }

            //GD.Print($"(BrsSSS_Panel, OnCopyNodePathWithMethod1) nodePath: {nodePath}\n");
            string returnVal;

            if(!useGDscript)
            {
                // Prepare the result string to copy to the clipboard
                returnVal = $"var someVar = GetNode(\"{nodePath}\");";
            }
            else
            {
                returnVal = $"var some_var = get_node(\"{nodePath}\");";
            }
            

            // Copy the result into the clipboard
            DisplayServer.ClipboardSet(returnVal);
            //GD.Print($"(BrsSSS_Panel, OnCopyNodePathWithMethod1) Copied to clipboard: {returnVal}\n");
        }
        
        //Truncating editor node path to scene path:
        private void OnCopyNodePathWithMethod_Truncate()
        {
            GD.PrintErr($"(TscnData, OnCopyNodePathWithMethod1) started ------");

            // Get the selected node from the editor's selection
            //var selectedNodes = EditorInterface.Singleton.GetSelection();
            var selectedNodes = BrsEditor.GetSelectedNodes();
            if (selectedNodes != null && selectedNodes.Count > 0)
            {
                // Get the actual path of the node within the scene
                string nodePath = selectedNodes[0].GetPath();  // This will return the runtime path (relative to the scene root)
                //GD.Print($"(BrsSSS_Panel, OnCopyNodePathWithMethod1) nodePath: {nodePath}\n");

                // Reverse the node path to target the first '/<4 digits>@' from the original string
                string reversedNodePath = new string(nodePath.Reverse().ToArray());
                //GD.Print($"(BrsSSS_Panel, OnCopyNodePathWithMethod1) reversedNodePath: {reversedNodePath}\n");

                // Debugging: Log the matches using Regex.Matches to check if the pattern matches
                var matches = Regex.Matches(reversedNodePath, @"/(\d{4}@)");

                // Log the matches
                if (matches.Count == 0)
                {
                    GD.PrintErr("(BrsSSS_Panel, OnCopyNodePathWithMethod1) No matches found in reversed node path.");
                    return; // Stop execution if no match is found
                }

                foreach (Match match in matches)
                {
                    //GD.Print($"(BrsSSS_Panel, OnCopyNodePathWithMethod1) Regex match: {match.Value}\n");
                }

                // First pass: remove everything after the first match of '/<4 digits>@' in the reversed string
                string reversedModifiedNodePath = Regex.Replace(reversedNodePath, @"/(\d{4}@).*", "");

                // Debugging: Log the modified reversed path after the regex
                //GD.Print($"(BrsSSS_Panel, OnCopyNodePathWithMethod1) reversedModifiedNodePath (after regex): {reversedModifiedNodePath}\n");

                // Now, no need for the second pass; since we've already modified the string using Regex.Replace
                // Reverse the modified path back to its original order
                string modifiedNodePath = new string(reversedModifiedNodePath.Reverse().ToArray());

                // Debugging the modified path
                //GD.Print($"(BrsSSS_Panel, OnCopyNodePathWithMethod1) modifiedNodePath: {modifiedNodePath}\n");

                // Prepare the result string to copy to the clipboard
                string returnVal = $"GetNode(\"{modifiedNodePath}\");";

                // Copy the result into the clipboard
                DisplayServer.ClipboardSet(returnVal);
                //GD.Print($"(BrsSSS_Panel, OnCopyNodePathWithMethod1) Copied to clipboard: {returnVal}\n");
            }
            else
            {
                GD.PrintErr("(BrsSSS_Panel, OnCopyNodePathWithMethod1) Node not found in the scene.");
            }
        }

        
        private void OnDisableAddon_ButtonPressed()
        {
            if (addonNames == null || addonNames.Length == 0)
            {
                addonNames = ParseNames(addonNames_TextEdit.Text);
            }

            foreach (var addonName in addonNames)
            {
                if (addonName != null)
                {
                    // Disable the addon
                    EditorInterface.Singleton.SetPluginEnabled(plugin: addonName, enabled: false);
                    //GD.Print($"Addon: {addonName} enabled.");
                }
                else
                {
                    GD.PrintErr($"Addon: {addonName}  plugin not found!");
                }
            }
        }

        private void OnEnableAddon_ButtonPressed()
        {
            if (addonNames == null || addonNames.Length == 0)
            {
                addonNames = ParseNames(addonNames_TextEdit.Text);
            }


            foreach (var addonName in addonNames)
            {
                if (addonName != null)
                {
                    // Disable the addon
                    EditorInterface.Singleton.SetPluginEnabled(plugin: addonName, enabled: true);
                    //GD.Print($"Addon: {addonName} enabled.");
                }
                else
                {
                    GD.PrintErr($"Addon: {addonName}  plugin not found!");
                }
            }
        }

        private Dictionary<Timer, string> timerToAddonMap = new Dictionary<Timer, string>();

        private void OnReEnableAddon_ButtonPressed()
        {
            if (addonNames == null || addonNames.Length == 0)
            {
                addonNames = ParseNames(addonNames_TextEdit.Text);
            }

            foreach (var addonName in addonNames)
            {
                if (!string.IsNullOrEmpty(addonName))
                {
                    // Disable the addon
                    EditorInterface.Singleton.SetPluginEnabled(addonName, false);
                    //GD.Print($"Addon: {addonName} disabled.");

                    // Create a Timer node
                    Timer timer = new Timer
                    {
                        WaitTime = 0.5, // 1 second delay
                        OneShot = true,  // Trigger only once
                        Autostart = true
                    };

                    // Store the addonName before starting the timer
                    timerToAddonMap[timer] = addonName;

                    // Use the new Callable system in Godot 4
                    timer.Timeout += () => OnTimerTimeout(timer);

                    // Add timer to the scene and start it
                    var root = EditorInterface.Singleton.GetBaseControl();
                    root.AddChild(timer);
                    timer.Start();
                }
                else
                {
                    GD.PrintErr("Addon name is null or empty.");
                }
            }
        }

        private void OnTimerTimeout(Timer timer)
        {
            if (timerToAddonMap.TryGetValue(timer, out string addonName))
            {
                EditorInterface.Singleton.SetPluginEnabled(addonName, true);
                //GD.Print($"Addon: {addonName} re-enabled.");

                // Clean up
                timerToAddonMap.Remove(timer);
                timer.QueueFree();
            }
        }

        private void OnrestartEditor_ButtonPressed()
        {
            EditorInterface.Singleton.RestartEditor(true);
        }

        private void OnDelGDtemp_ButtonPressed()
        {
            string folderPath = "res://.godot";
            string fullPath = ProjectSettings.GlobalizePath(folderPath);
            
            if (Directory.Exists(fullPath))
            {
                // Recursively delete all files and subdirectories
                Directory.Delete(fullPath, true);
            }
            else
            {
                throw new DirectoryNotFoundException($"Directory not found: {fullPath}");
            }
            GD.Print($".godot deleted");
        }
        
        private void OnOpenUserFolder_Button()
        {
            string fullPath = ProjectSettings.GlobalizePath("user://");
            OS.ShellShowInFileManager(fullPath);
        }
   
        private void OnOpenProjectFolder_Button()
        {
            string fullPath = ProjectSettings.GlobalizePath("res://");
            OS.ShellShowInFileManager(fullPath);
        }

        public static string[] ParseNames(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return new string[0];

            // Split the string on commas, remove empty entries, then trim whitespace and quotes from each element.
            string[] names = input
                .Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(item => item.Trim().Trim('\"'))
                .ToArray();

            return names;
        }

        private void OnAddonNames_TextEdit()
        {
            string text = addonNames_TextEdit.Text;
            brsConfigManager.Set("addonNames_TextEdit", text);
            SaveConfig();
        }
                
    #endregion  ----- UI Methods -----

    #region ----- Main Methods -----

        

    #endregion ----- Main Methods -----

    #region ----- Misc Methods -----

        

    #endregion ----- Misc Methods -----


    public void OnBeforeSerialize()
    {
        UnloadSignals();
    }

    public void OnAfterDeserialize()
    {
        InitializeUINodes();
    }

    void InitializeUINodes()
    {
                
        #region - Initialize UI Nodes -

            // Initialize UI Nodes and BrsConfigManager

            test_Button = (Button)GetNode("%Test_Button");
            test_Button.Pressed += OnTest_Button;

            selectedToCustom1_Button = (Button)GetNode("%SelectedToCustom1_Button");
            selectedToCustom1_Button.Pressed += OnSelectedToCustom1_Button;
            customTemplate1_TextEdit = (TextEdit)GetNode("%CustomTemplate1_TextEdit");
            customTemplate1_TextEdit.TextChanged += OnCustomTemplate1_TextEdit;
            customTemplate1_TextEdit.Text = brsConfigManager.Get<string>("customText1");

            selectedToCustom2_Button = (Button)GetNode("%SelectedToCustom2_Button");
            selectedToCustom2_Button.Pressed += OnSelectedToCustom2_Button;
            customTemplate2_TextEdit = (TextEdit)GetNode("%CustomTemplate2_TextEdit");
            customTemplate2_TextEdit.TextChanged += OnCustomTemplate2_TextEdit;
            customTemplate2_TextEdit.Text = brsConfigManager.Get<string>("customText2");
            
            selectedToCustom3_Button = (Button)GetNode("%SelectedToCustom3_Button");
            selectedToCustom3_Button.Pressed += OnSelectedToCustom3_Button;
            customTemplate3_TextEdit = (TextEdit)GetNode("%CustomTemplate3_TextEdit");
            customTemplate3_TextEdit.TextChanged += OnCustomTemplate3_TextEdit;
            customTemplate3_TextEdit.Text = brsConfigManager.Get<string>("customText3");

            setUnique_CheckBox = (CheckBox)GetNode("%SetUnique_CheckBox");
            setUnique_CheckBox.ToggleMode = true;
            setUnique_CheckBox.Toggled += OnSetUnique_CheckBox;
            setUnique_CheckBox.ButtonPressed = brsConfigManager.Get<bool>("setUnique");


            node1_Button = (Button)GetNode("%Node1_Button");
            node1_Button.Pressed += SetNode1;
            node2_Button = (Button)GetNode("%Node2_Button");
            node2_Button.Pressed += SetNode2;

            delGDtemp_Button = (Button)GetNode("%DelGDtemp_Button");
            delGDtemp_Button.Pressed += OnDelGDtemp_ButtonPressed;

            
            disableAddons_Button = GetNode<Button>("%DisableAddons_Button");
            disableAddons_Button.Pressed += OnDisableAddon_ButtonPressed;
            
            enableAddons_Button = GetNode<Button>("%EnableAddons_Button");
            enableAddons_Button.Pressed += OnEnableAddon_ButtonPressed;
            
            restartAddons_Button = GetNode<Button>("%RestartAddons_Button");
            restartAddons_Button.Pressed += OnReEnableAddon_ButtonPressed;
            
            openUserFolder_Button = (Button)GetNode("%OpenUserFolder_Button");
            openUserFolder_Button.Pressed += OnOpenUserFolder_Button;
            openProjectFolder_Button = (Button)GetNode("%OpenProjectFolder_Button");
            openProjectFolder_Button.Pressed += OnOpenProjectFolder_Button;

            addonNames_TextEdit = (TextEdit)GetNode("%AddonNames_TextEdit");
            addonNames_TextEdit.TextChanged += OnAddonNames_TextEdit;
            addonNames_TextEdit.Text = brsConfigManager.Get<string>("addonNames_TextEdit");

            gotIt_Button = (Button)GetNode("%GotIt_Button");
            gotIt_Button.Pressed += OnGotIt_Button;

            if(brsConfigManager.Get<bool>("gotIt_Button")) gotIt_Button.EmitSignal("pressed");

            manual_Button = (Button)GetNode("%Manual_Button");
            manual_Button.Pressed += OnManual_Button;

        
        #endregion - Initialize UI Nodes -
    
    }

    void UnloadSignals()
    {
        test_Button.Pressed -= OnTest_Button;
        selectedToCustom1_Button.Pressed -= OnSelectedToCustom1_Button;
        customTemplate1_TextEdit.TextChanged -= OnCustomTemplate1_TextEdit;
        selectedToCustom2_Button.Pressed -= OnSelectedToCustom2_Button;
        customTemplate2_TextEdit.TextChanged -= OnCustomTemplate2_TextEdit;
        selectedToCustom3_Button.Pressed -= OnSelectedToCustom3_Button;
        customTemplate3_TextEdit.TextChanged -= OnCustomTemplate3_TextEdit;
        setUnique_CheckBox.Toggled -= OnSetUnique_CheckBox;
        node1_Button.Pressed -= SetNode1;
        node2_Button.Pressed -= SetNode2;
        delGDtemp_Button.Pressed -= OnDelGDtemp_ButtonPressed;
        disableAddons_Button.Pressed -= OnDisableAddon_ButtonPressed;
        enableAddons_Button.Pressed -= OnEnableAddon_ButtonPressed;
        restartAddons_Button.Pressed -= OnReEnableAddon_ButtonPressed;
        openUserFolder_Button.Pressed -= OnOpenUserFolder_Button;
        openProjectFolder_Button.Pressed -= OnOpenProjectFolder_Button;
        addonNames_TextEdit.TextChanged -= OnAddonNames_TextEdit;
        gotIt_Button.Pressed -= OnGotIt_Button;
        manual_Button.Pressed -= OnManual_Button;
    }

    public override void _ExitTree()
    {
        // Write all stored values to the config file
        ///CallDeferred(nameof(SaveConfig));
        //GD.Print("(TemplatePanel._ExitTree) Configuration saved.");

        UnloadSignals();
    }

    public void SaveConfig()
    {
        brsConfigManager.SaveConfig();
    }
}
#endif
